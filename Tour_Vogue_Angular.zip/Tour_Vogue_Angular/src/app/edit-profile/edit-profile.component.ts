import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  editObject : any;
  userId : any;
  userName : any;

  constructor(private service : ServiceService) { 
    this.editObject = {firstName :'', lastName : '', email : '', mobileNo : '', state : '', password : ''};
  }

  ngOnInit(): void {
    this.userId = localStorage.getItem('userId');
    this.userName = localStorage.getItem('firstName');
    this.service.getUserById(this.userId).subscribe( (result: any) => {
      console.log(result); 
      this.editObject = result; 
    });
  }
  updateUser() {
  this.service.updateUser(this.editObject).subscribe(
    data => {
      console.log('done');
    }
  );
  console.log(this.editObject);
  setTimeout(() => {this.ngOnInit()}, 1000*2);
}

}
