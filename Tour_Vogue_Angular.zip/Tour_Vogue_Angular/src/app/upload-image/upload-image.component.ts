import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';

@Component({
  selector: 'app-upload-image',
  templateUrl: './upload-image.component.html',
  styleUrls: ['./upload-image.component.css']
})
export class UploadImageComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  userId : any;

  constructor(private service: ServiceService) {
    //this.imageUrl = 'assets/img/1003.png';
  }

  ngOnInit(): void {
    this.userId = localStorage.getItem('userId');
  }
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    this.service.postFile(imageForm, this.fileToUpload, this.userId).subscribe (
      data => {
        console.log('done');
        //this.imageUrl = 'assets/Images/1002.jpg';
      }
    );
  }

}