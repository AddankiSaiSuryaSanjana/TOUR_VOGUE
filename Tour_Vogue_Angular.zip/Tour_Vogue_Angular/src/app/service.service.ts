import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private isUserLogged: any;
  private isUserTasks : any;
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    this.isUserTasks = false;
   }
   setUserTaskIn() : void {
     this.isUserTasks = true;
   }
   setUserTaskOut() : void {
     this.isUserTasks = false;
   }
   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
   getUserTask() : any {
     return this.isUserTasks;
   }
   getCountriesList(): any {
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }
   getUser(loginId : any, password : any): any {
    return this.httpClient.get('RestAPI/webapi/myresource/getUserByUserPass/' + loginId + '/' + password);
   }
   getEmpById(empId: any) {
    return this.httpClient.get('RestAPI/webapi/myresource/getEmployeeById/' + empId);
   }
   registerUser(user: any) {
    return this.httpClient.post('RestAPI/webapi/myresource/registerUser/',  user);
   }
   validateUser(user : any) {
    return this.httpClient.post('RestAPI/webapi/myresource/getUserByUserPass/', user);
   }
   deleteTask(task: any) {
    return this.httpClient.get('RestAPI/webapi/myresource/deleteTask/' + task.taskId);
   }
   getUserById(userId : any) {
     return this.httpClient.get('RestAPI/webapi/myresource/getUserById/' + userId);
   }
   updateTask(editObject: any) {
     console.log('before restapi call')
    return this.httpClient.put('RestAPI/webapi/myresource/updateTask/', editObject);
   }
   updateUser(editObject: any) {
    console.log('before restapi call')
    return this.httpClient.put('RestAPI/webapi/myresource/updateUser/', editObject);
  }
  getAllDepartments(): any {
    return this.httpClient.get('RestAPI/webapi/myresource/getDepartments');
   }
   //getImage(): Observable<File> {
    //console.log('Inside Service...');
    //return this.httpClient.get('RestAPI/webapi/myresource/downloadImage', { responseType: 'blob' });
 //}
 getProducts() {
  return this.httpClient.get('RestAPI/webapi/myresource/getItems').pipe(retry(10));
 }
 getTasks(userId : any) {
  return this.httpClient.get('RestAPI/webapi/myresource/getTasks/' + userId);
 }

 postFile(ImageForm: any, fileToUpload: File, userId : any) {
  // const endpoint='RESTAPI/webapi/myresource/';
  const formData: FormData = new FormData();
  formData.append('itemImage', fileToUpload, fileToUpload.name);
  formData.append('itemName', ImageForm.itemName);
  formData.append('itemDescription', ImageForm.itemDescription);
  formData.append('itemType', ImageForm.itemType);
  formData.append('userId', userId);
  console.log("before restapi call");
  return this.httpClient.post('RestAPI/webapi/myresource/uploadImage', formData);
  }   
  addTaskRestapi(taskForm : any, userId : any) {
    const formData: FormData = new FormData();
    formData.append('taskPlace', taskForm.taskPlace);
    formData.append('taskDescription', taskForm.taskDescription);
    formData.append('userId', userId);
    console.log("before restapi call task");
    return this.httpClient.post('RestAPI/webapi/myresource/addTask', formData);
  }
}
