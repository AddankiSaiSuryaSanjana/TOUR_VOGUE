import { Component, OnInit } from '@angular/core';
import {NgStyle} from '@angular/common'
import { ServiceService } from '../service.service';
import {RouterModule, Routes, Router} from '@angular/router';
import { from } from 'rxjs';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  countries: any;
  user: any;
  constructor(private router : Router, private service: ServiceService) {
    this.user = {userId: '', firstName: '', lastName: '', email: '', mobileNo: '', state: '', password : ''};
  }

  ngOnInit() {
    this.service.getCountriesList().subscribe((data: any) => {console.log(data); this.countries = data; });
  }
  register(): void {
    this.service.registerUser(this.user).subscribe((result: any) => { console.log(result); } );
    console.log(this.user);
    this.router.navigate(['login']);
  }
}
