import { Component, OnInit } from '@angular/core';
import {NgStyle} from '@angular/common'
import {RouterModule, Routes, Router} from '@angular/router';
import { from } from 'rxjs';
import { ServiceService } from '../service.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  data : any;
  constructor(private router : Router, private service: ServiceService, private httpClient : HttpClient) { 
    this.data =  {userId: '', firstName: '', lastName: '', email: '', mobileNo: '', loginId: '', password : ''};
  }

  ngOnInit(): void {
  }
  validateUser(loginForm : any) : void {
    this.service.getUser(loginForm.loginId, loginForm.password).subscribe((result: any) => {
      if(result === null) {
      alert('Invalid Credentials');
    } else {
      alert('Successfully Logged In');
      this.service.setUserLoggedIn();
      localStorage.setItem('firstName', result.firstName);
      console.log(localStorage.getItem('firstName'));
     this.router.navigate(['showemp']);

    } });
 }
}
