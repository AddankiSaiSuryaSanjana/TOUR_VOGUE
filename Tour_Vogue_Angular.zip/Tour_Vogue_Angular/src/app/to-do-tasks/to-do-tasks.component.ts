import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { element } from 'protractor';
import { Router } from '@angular/router';
declare var jQuery : any;

@Component({
  selector: 'app-to-do-tasks',
  templateUrl: './to-do-tasks.component.html',
  styleUrls: ['./to-do-tasks.component.css']
})
export class ToDoTasksComponent implements OnInit {
  tasks:any;
  editObject : any;
  userId : any;
  constructor(private service : ServiceService, private router : Router) {
    this.editObject = {taskId: '', taskPlace: '', taskDescription : ''};
   }

  ngOnInit(): void {
    this.userId = localStorage.getItem('userId');
    this.service.getTasks(this.userId).subscribe( (result: any) => {
      console.log(result); 
      this.tasks = result; 
    });
    setTimeout(() => {this.ngOnInit()}, 1000*2);
  }
  
  getTasksAngular() {
    this.service.getTasks(this.userId).subscribe( (result: any) => {
      console.log(result); 
      this.tasks = result; 
    });
  }
  deleteTask(task : any) {
    this.service.deleteTask(task).subscribe((data : any) => {
      const i = this.tasks.findIndex((element) => {return task.taskId === task.taskId
      });
      this.tasks.splice(i, 1);
    });
    console.log('Inside delete function' + JSON.stringify(task));
  }

  showEditPopup(task: any) {
    console.log('Inside pop up');
    this.editObject = task;
    jQuery('#empModel').modal('show');
  }
  updateTask() {
    this.service.updateTask(this.editObject).subscribe(
      data => {
        console.log('done');
      }
    );
    console.log(this.editObject);
  }
  onSubmit(taskForm : any) {
    this.service.addTaskRestapi(taskForm, this.userId).subscribe(      
      data => {
      console.log('done');
    }
  );
  }
  userToDoOut() {
    this.service.setUserTaskOut();
    this.router.navigate(['showemp']);
  }

}
