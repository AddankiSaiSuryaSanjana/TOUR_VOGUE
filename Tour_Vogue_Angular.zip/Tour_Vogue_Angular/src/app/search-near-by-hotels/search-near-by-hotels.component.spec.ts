import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchNearByHotelsComponent } from './search-near-by-hotels.component';

describe('SearchNearByHotelsComponent', () => {
  let component: SearchNearByHotelsComponent;
  let fixture: ComponentFixture<SearchNearByHotelsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchNearByHotelsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchNearByHotelsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
