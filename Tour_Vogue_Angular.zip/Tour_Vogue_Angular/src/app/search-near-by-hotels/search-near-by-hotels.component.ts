import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-search-near-by-hotels',
  templateUrl: './search-near-by-hotels.component.html',
  styleUrls: ['./search-near-by-hotels.component.css']
})
export class SearchNearByHotelsComponent implements OnInit {
 options : any = {
    method: 'GET',
    url: 'https://hotels4.p.rapidapi.com/locations/search',
    qs: {query: 'kakinada', locale: 'en_US'},
    headers: {
      'x-rapidapi-key': '331c0c351emshbb5fbd2bc2139c9p19e37ajsn17c4efe81070',
      'x-rapidapi-host': 'hotels4.p.rapidapi.com',
      useQueryString: true
    }
  };
    hotels : any;
    r : any;
    h : any;
  constructor(private service: ServiceService, private httpClient: HttpClient) { 
    /*this.httpClient.get(this.options).toPromise().then(data => {
      //console.log(data);
      this.r = data.suggestions;
      console.log(this.r);
      for (var re of this.hotels) {
        this.h = re.group;
        if (this.h == "HOTEL_GROUP")
            this.hotels = (re.entities);
      } 
     console.log(this.hotels);
    });*/
  }

  ngOnInit(): void {
  }
}
