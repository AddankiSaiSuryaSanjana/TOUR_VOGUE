import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-search-near-by',
  templateUrl: './search-near-by.component.html',
  styleUrls: ['./search-near-by.component.css']
})
export class SearchNearByComponent implements OnInit {
  url1 : any;
  url2 : any;
  item : any;
  items : any;
  constructor(private service: ServiceService, private httpClient: HttpClient) { 
  }

  ngOnInit(): void {
  }
  validateSearch(cty : any) : any {
    this.url1 = 'https://developers.zomato.com/api/v2.1/cities?q='+cty+'&apikey=be74a37f49ed269d7f8ac9a99bcb4f59';
    this.httpClient.get(this.url1).toPromise().then(data => {
      //console.log(data);
      this.item = data.location_suggestions[0].id;
      console.log(this.item);
    });
    this.url2 = 'https://developers.zomato.com/api/v2.1/search?entity_id='+this.item+'&entity_type=city&order=asc&apikey=be74a37f49ed269d7f8ac9a99bcb4f59'
    this.httpClient.get(this.url2).toPromise().then(data => {
      //console.log(data);
      this.items = data.restaurants;
      console.log(this.items);
    });
  }
  validateBestRateSearch(cty : any) : any {
      this.url1 = 'https://developers.zomato.com/api/v2.1/cities?q='+cty+'&apikey=be74a37f49ed269d7f8ac9a99bcb4f59';
      this.httpClient.get(this.url1).toPromise().then(data => {
        //console.log(data);
        this.item = data.location_suggestions[0].id;
        console.log(this.item);
      });
      this.url2 = 'https://developers.zomato.com/api/v2.1/search?entity_id='+this.item+'&entity_type=city&sort=rating&order=desc&apikey=be74a37f49ed269d7f8ac9a99bcb4f59'
      this.httpClient.get(this.url2).toPromise().then(data => {
        //console.log(data);
        this.items = data.restaurants;
        console.log(this.items);
      });
  }

}
