import { ExpPipe } from './exp.pipe';

describe('ExpPipe', () => {
  it('create an instance', () => {
    const pipe = new ExpPipe();
    expect(pipe).toBeTruthy();
  });
});
