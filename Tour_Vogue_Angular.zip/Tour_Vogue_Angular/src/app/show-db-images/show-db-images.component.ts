import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';
@Component({
  selector: 'app-show-db-images',
  templateUrl: './show-db-images.component.html',
  styleUrls: ['./show-db-images.component.css']
})
export class ShowDbImagesComponent implements OnInit {
  items: any;

  constructor(private service: ServiceService) { }

  ngOnInit() {
    this.service.getProducts().subscribe( (result: any) => {
      console.log(result); 
      this.items = result; 
    });
  }
}


