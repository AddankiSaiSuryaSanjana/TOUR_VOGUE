import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit {
  firstName : any;
  constructor() { }
  ngOnInit(){
    //this.products = [{id:1001, name:'MOBILE', description:'No cost EMI from Rs1,499/-', price:19999.99, imagePath:'../assets/images/1001.webp'},
    //{id:1002, name:'MOBILE', description:'Samsung Galaxy J7 Max', price:15000.00, imagePath:'assets/images/1002.jpg'},
    //{id:1003, name:'MOBILE', description:'Apple iphone 11', price:20000.00, imagePath:'assets/images/1003.png'}];
    this.firstName = localStorage.getItem('firstName');
  }

}
