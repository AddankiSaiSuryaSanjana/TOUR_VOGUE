import { Component, OnInit } from '@angular/core';
import {NgStyle} from '@angular/common'
import { ViewChild,ElementRef } from '@angular/core'
import {RouterModule, Routes, Router} from '@angular/router';
import { from } from 'rxjs';
import { ServiceService } from '../service.service';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  @ViewChild('loginRef', {static: true })loginElement: ElementRef;
  auth2 : any;
  data : any;
  constructor(private router : Router, private service: ServiceService, private httpClient : HttpClient) { 
    this.data =  {userId: '', firstName: '', lastName: '', email: '', mobileNo: '', loginId: '', password : ''};
  }


  ngOnInit() {
    this.googleInitialize();
  }
  validateUser(loginForm : any) : void {
    this.service.getUser(loginForm.loginId, loginForm.password).subscribe((result: any) => {
      if(result === null) {
      alert('Invalid Credentials');
    } else {
      this.service.setUserLoggedIn();
      localStorage.setItem('firstName', result.firstName);
      localStorage.setItem('userId', result.userId);
      console.log(localStorage.getItem('firstName'));
      this.router.navigate(['showemp']);

    } });
 }

  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '729998156722-ogtimt6dm6o0rtv46jecc41gigd7mp14.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }  

}
