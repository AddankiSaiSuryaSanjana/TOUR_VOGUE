import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../service.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userName : any;
  constructor(private service: ServiceService, private httpClient: HttpClient, private router : Router) { 
    this.userName = localStorage.getItem('firstName');
  }
  ngOnInit(): void {
  }
  
  userLogout() : void {
    this.service.setUserLoggedOut();
    this.router.navigate(['']);
  }  
  userToDo() : void {
    this.service.setUserTaskIn();
    this.router.navigate(['todo']);
  }
}