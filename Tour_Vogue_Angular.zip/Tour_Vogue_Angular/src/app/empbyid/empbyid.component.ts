import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-empbyid',
  templateUrl: './empbyid.component.html',
  styleUrls: ['./empbyid.component.css']
})
export class EmpbyidComponent implements OnInit {
  employee : any;
  empId : any;
  constructor(private service : ServiceService) { }

  ngOnInit(): void {

  }
  getEmpById(empId : any) : any {
    this.service.getEmpById(empId).subscribe((data: any) => {console.log(data); this.employee = data; });
  }
}
