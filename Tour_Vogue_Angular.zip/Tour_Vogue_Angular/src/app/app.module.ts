import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { LoginComponent } from './login/login.component';
import { ShowEmpComponent } from './show-emp/show-emp.component';
import { ExpPipe } from './exp.pipe';
import { GenderPipe } from './gender.pipe';
import { RegisterComponent } from './register/register.component';
import {ProductsComponent} from './products/products.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AuthGuard } from './auth.guard';
import { LogoutComponent } from './logout/logout.component';
import { from } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { EmpbyidComponent } from './empbyid/empbyid.component';
import { HomeComponent } from './home/home.component';
import { ShowDbImagesComponent } from './show-db-images/show-db-images.component';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { SearchNearByComponent } from './search-near-by/search-near-by.component';
import { SearchNearByHotelsComponent } from './search-near-by-hotels/search-near-by-hotels.component';
import { ToDoTasksComponent } from './to-do-tasks/to-do-tasks.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component'; 
const appRoot : Routes = [{path:'', component:ShowEmpComponent},
                          {path:'login', component:TestComponent},
                          {path:'uploadimg', component:UploadImageComponent},
                          {path:'edit-profile', component:EditProfileComponent},
                          {path:'showimg', component:ShowDbImagesComponent},
                          {path:'todo', component:ToDoTasksComponent},
                          {path:'searchnearbyhotels', component:SearchNearByHotelsComponent},
                          {path:'searchnearbyres', component:SearchNearByComponent},
                          {path:'register', component:RegisterComponent},
                          {path:'showemp', component: ShowEmpComponent},
                          {path:'empbyid', canActivate:[AuthGuard], component: EmpbyidComponent},
                        {path:'logout', canActivate:[AuthGuard], component : LogoutComponent}]
@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    LoginComponent,
    ShowEmpComponent,
    ExpPipe,
    GenderPipe,
    RegisterComponent,
    ProductsComponent,
    HeaderComponent,
    FooterComponent,
    LogoutComponent,
    EmpbyidComponent,
    HomeComponent,
    ShowDbImagesComponent,
    UploadImageComponent,
    SearchNearByComponent,
    SearchNearByHotelsComponent,
    ToDoTasksComponent,
    EditProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    MDBBootstrapModule.forRoot(),
    RouterModule.forRoot(appRoot),HttpClientModule
  ],
  providers: [AuthGuard ],
  bootstrap: [AppComponent]
})
export class AppModule { }
