import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { element } from 'protractor';
declare var jQuery : any;
import { Router } from '@angular/router';
@Component({
  selector: 'app-show-emp',
  templateUrl: './show-emp.component.html',
  styleUrls: ['./show-emp.component.css']
})
export class ShowEmpComponent implements OnInit {
  employees :any;
  editObject : any;
  userName : any;
  constructor(private service : ServiceService, private router : Router) {
/*    this.employees = [{empId : 101, empName : 'NANDAM', gender :'M', salary :9999.99, dob:new Date('07/25/1969'), mobile :9849534439, country:'India'},
    {empId : 102, empName : 'MANI', gender :'F', salary :8888.88, dob:new Date('11/14/1981'), mobile:9542552006, country:'srilanka'},
    {empId : 103, empName : 'SAMYU', gender :'F', salary :7777.77, dob:new Date('04/30/2001'), mobile:7095397439, country:'USA'},
    {empId : 104, empName : 'RISHI', gender :'F', salary : 6666.66, dob:new Date('11/11/2004'), mobile:9441460539, country:'australia'}];
  */
 this.editObject = {empId: '', empName: '', gender: '', salary: '' , doj: '', mobile: '', country: ''};
}
  ngOnInit(): void {
    this.userName = localStorage.getItem('firstName');
  }
  userLogout() : void {
    this.service.setUserLoggedOut();
    this.router.navigate(['login']);
}  

}
